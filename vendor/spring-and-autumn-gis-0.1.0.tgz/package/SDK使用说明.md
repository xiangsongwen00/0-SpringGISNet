# SDK 使用说明

2026-10-11更新。引擎仓库负责库输出；独立交互、TS/JS消费和应用构建放在 **E:\0-SpringGISNet**。不再从本仓库通过demo:sdk创建临时消费者或启动交互服务。

完整类/属性/类型/方法/返回值/错误/示例见 [SDK接口参考](SDK接口参考.md)，随安装包发布。本文侧重构建部署和历史实现边界；以接口参考和最新增量为当前调用约定。

## 本轮增量：绘制样式、ID选择与工具栏（2026-10-11）

工具栏默认离容器底部48px并加safe-area，toolbar.bottomOffset或CSS `--sag-toolbar-bottom`可覆盖；小弹窗同样偏移。标准7个图标，源码有业务层扩展共8个，对象管理收进绘制弹窗。源页面完整表单通过drawContent挂载到该弹窗，关闭恢复原DOM并隐藏；独立TS/ES6页同样复用完整表单，不复制ID/监听或建立第二套集合。

图标不生效的已确认分叉：工具栏默认draw.start未读取已有表单符号，且会话样式被复制。修为同一EntityDrawingController，增加draw.setStyle(type,style)/getStyle(type)，按类型默认样式与活动同类型会话即时更新；已提交对象仍用entities.update或“应用到选中对象”明确更新，不无界批量改全部业务对象。表单change/开始读取完整图标/纹理参数；连续点提交期间不自动载入对象表单覆盖用户绘制预设。关掉icon/texture使用null移除，颜色白色保留原图色。

已有entities.getById/query/update/move/显隐无需重复实现；新增entities.selectById/selectedId/selectedEntity、viewer.selectEntity/selectedEntity，ID稳定、位置/符号更新后读取最新快照；删除/清空撤销选择。selection事件不重建GPU、不自动高亮/飞行，可为实时定位/轨迹的选中上下文。viewer.coordinates公开已有转换器，sampleTerrainHeight仅查已可用DEM、未知null，不自动加载全球高程；屏幕高程仍用pickPositionDetailed并检查source。

清理仅针对旧临时消费者和无npm引用的手工CDP诊断探针，先归档ZIP并核对条目/校验，再移出源码；核心DEM/XYZ-TMS/矢量/拾取/实体回归保留。恢复路径见archives/README.md，归档不进入SDK安装包。MVT底图/业务瓦片和地图注记仍为实验性，能力限制在接口参考专章列明，本轮不扩大样式/符号成熟度承诺。

## 1. 引擎只构建 dist

CMD 示例（npm命令也可在PowerShell中执行，切目录语法不同）：

```bat
cd /d E:\SpringAndAutumnGIS\SpringAndAutumnGIS
npm run build
npm run test:sdk
```

上面cd /d是CMD语法；PowerShell切目录用Set-Location。build生成ES模块、CJS兼容入口和类型声明；test:sdk仅检查现有dist，不安装依赖、不启动服务。不运行浏览器，也不代表真实数据服务已验收。

- dist/spring-and-autumn-gis.es.js：ES6库。
- dist/spring-and-autumn-gis.umd.cjs：CommonJS兼容入口。
- dist/index.d.ts及各模块声明：TypeScript接口。
- 引擎dist不是网站，没有交互index.html。

发布可使用npm pack（prepack构建），或构建后npm pack --ignore-scripts。安装包只包含dist、公共文档及npm附带的包描述/许可/README；不带src、交互项目、token.json、全国数据或自有服务资源。Three为peer dependency。未发布npm registry。

## 2. 在实际独立项目消费

```bat
cd /d E:\0-SpringGISNet
npm run sdk:update
npm run dev
```

sdk:update将引擎**当前已生成的dist**打成vendor安装包并安装，不构建引擎、不读源码模块、不建立源码目录链接。引擎目录可用SDK_ENGINE_DIR指定；正常dev/build/preview不调用sdk:update，也不依赖引擎仓库仍然存在。

默认开发地址由应用config/pc.env.json决定，当前为5173：

- /：现有Vue站点，引擎区域嵌入交互页。
- /sdk.html：TypeScript消费。
- /sdk-js.html：JavaScript ES6消费。

两种消费源码都使用 `import { Viewer } from 'spring-and-autumn-gis'`。JS文件为实际ES模块，不是让浏览器执行TS。详见独立项目的SDK接入说明.md。

应用生产构建/预览：

```bat
cd /d E:\0-SpringGISNet
npm run build
npm run preview
```

默认preview端口4173。直接服务应用dist；不重新打包引擎、不生成临时项目。静态服务器部署整个应用dist（HTML和assets一起），而不是把引擎库文件当HTML页面打开。Vite仅为应用开发/预览工具，不是SDK运行时必须部署的服务器。

## 3. Viewer最小用法

```js
import { Viewer } from 'spring-and-autumn-gis';

async function main() {
  const viewer = await Viewer.create('map', {
    basemaps: [
      { id: 'image', type: 'xyz', url: '/tiles/{z}/{x}/{y}.png',
        scheme: 'xyz', maxLevel: 20, levelOffset: -1.7 },
      { id: 'vector', type: 'vector-style', style: '/styles/map.json', symbols: true }
    ],
    baseMap: 'image',
    terrain: false,
    showLodGrid: false,
    initialView: { longitude: 106.55, latitude: 29.61, altitude: 12000 }
  });
  await viewer.setBaseMap('vector');
  viewer.setLodGridVisible(true);
  viewer.flyTo({ longitude: 106.55, latitude: 29.61, altitude: 2000, pitch: -45, duration: 700 });
  // 页面/组件退出时viewer.destroy()，不是初始化后立即销毁。
  return viewer;
}
main().catch(console.error);
```

容器必须有尺寸。地址由应用提供。create和setBaseMap表示配置就绪，不表示所有瓦片已经加载。普通交互页不自动销毁地图；自动回归才进行销毁/重建验证。

## 4. 公共接口与边界

- Viewer.create：DOM/id容器，basemaps、baseMap、terrain、showLodGrid、autoStart、signal、initialView及低层LOD/导航/回调配置。默认第一底图，baseMap:null为无底图，showLodGrid默认false。
- setBaseMap(id|null)：XYZ/TMS、借用RasterTileProvider、Style v8 GPU矢量统一切换，保留业务图层。配置失败保留原底图；被新请求取代的旧请求抛ABORTED。
- setTerrainEnabled：需初始化时配置DEM Provider。初始enabled:false不请求DEM；不支持运行中替换DEM Provider。
- setLodGridVisible：隐藏经纬网，不关闭地图LOD；隐藏时跳过网格更新。
- flyTo、getCameraViewState：WGS84角度与高度米，pitch -90俯视、0水平，duration毫秒。
- start、stop、destroy：stop暂停渲染但不承诺取消所有在途任务；destroy幂等，销毁后变更拒绝。
- baseMap、terrainEnabled、lodGridVisible、isDestroyed、getBaseMaps：状态/配置快照。
- engine：低层扩展入口，可复用GeoJsonLayer等，不要直接破坏SDK持有的base图层或__sdk_base_labels。
- ViewerError.code：INVALID_OPTIONS、BASEMAP_LOAD_FAILED、ABORTED、TERRAIN_UNAVAILABLE、DESTROYED。公共加载错误不回显后端凭据URL；浏览器WebGL构造错误可能直接抛出。

内部统一XYZ；scheme:tms只转换请求行号，显式{-y}不重复翻转，不改纹理/几何南北方向。借用Provider由调用方管理，Viewer创建的矢量Provider由Viewer释放。矢量是现有GPU地表管线与简化独立注记子集，不是完整MapLibre兼容实现；能力报告见baseMap.capabilities。旧GeoJsonLayer的面仍仅为边界；entities绘制/拾取/置顶/持续贴地见§4.1–4.4，图标工具栏和测量见§6.1。独立地形LOD和高级编辑仍未实施。

## 4.1 B版：点线面与标注对象

推荐使用 `viewer.entities`。四种type：point、polyline、polygon、label；任何几何也可附属label。底图切换保留这些业务对象，不与底图清单混用。无需通过engine手动增加GeoJSON图层。

```js
viewer.entities.add({
  id: 'station', type: 'point', name: '业务站点',
  position: [106.55, 29.61, 1500], properties: { category: 'station' },
  symbol: { shape: 'diamond', size: 22, color: '#ffd166', outlineColor: '#ffffff', outlineWidth: 2 },
  label: { text: '业务站点', fontSize: 18, color: '#ffffff', haloColor: '#173342', offset: [0, -30] }
});
viewer.entities.add({
  id: 'route', type: 'polyline',
  positions: [[106.52,29.60,1500], [106.55,29.61,1500], [106.59,29.62,1500]],
  symbol: { color: '#4bdcff', width: 5, opacity: 1, dash: [12, 6] }
});
viewer.entities.add({
  id: 'area', type: 'polygon',
  positions: [[106.51,29.63,1500], [106.57,29.63,1500], [106.57,29.67,1500], [106.51,29.67,1500]],
  holes: [[[106.53,29.64,1500], [106.55,29.64,1500], [106.55,29.66,1500], [106.53,29.66,1500]]],
  symbol: { fill: true, color: '#27e7a4', opacity: 0.5, outlineColor: '#ffffff', outlineWidth: 2 }
});
viewer.entities.add({ id: 'note', type: 'label', position: [106.58,29.65,1500],
  label: { text: '独立标注', fontSize: 18, backgroundColor: '#173342', padding: 5, offset: [0,0] } });

const station = viewer.entities.getById('station'); // 深度只读快照；查不到返回undefined
const stations = viewer.entities.query({ type: 'point', properties: { category: 'station' } });
viewer.entities.update('station', { symbol: { color: '#ff0066', size: 28 }, label: { text: '修改后的标注' } });
viewer.entities.move('station', { longitude: 0.01, latitude: 0, height: 100 });
viewer.entities.setVisibleById('station', false);
viewer.entities.setVisible(false); // 整个集合隐藏，保留各对象自己的visible标志
viewer.entities.setVisible(true);
viewer.entities.update('area', { symbol: { fill: false } });
viewer.entities.update('station', { label: null }); // 仅移除附属标注
const unsubscribe = viewer.entities.onChange(change => console.log(change.type, change.id));
viewer.entities.remove('route');
unsubscribe();
// viewer.entities.clear(); // 删除全部业务对象，不影响底图
```

| 接口 | 契约 |
| --- | --- |
| add(definition) | id必填且唯一，返回EntitySnapshot；不修改调用方的输入 |
| getById(id)、has(id)、values、length | 按ID/全量读取；values和对象属性均为冻结快照，不能直接赋值修改 |
| query({type,visible,name,properties,bounds}) | 条件AND；properties浅层精确值匹配，适合字符串/数值字段；bounds按几何首顶点/点位置查询，不是面相交查询，west>east支持跨日界线 |
| update(id,patch) | id/type不可变；symbol、label字段合并，position/positions/holes数组替换，properties整体替换；返回新快照，失败不改旧对象 |
| move(id,{longitude,latitude,height}) | 度／米增量；面和洞一起移动，经度归一化；不是ECEF刚体变换，越界纬度拒绝 |
| setVisibleById(id,bool)、setVisible(bool)、visible | 单对象／集合显隐；隐藏不释放资源，不被pick选中；元数据／显隐更新不重建几何 |
| remove(id)、clear() | 删除释放对象GPU资源；remove不存在ID返回false；clear不销毁集合 |
| onChange(listener) | add/update/remove/clear/visibility，update带fields；返回取消订阅函数，观察者异常不打断其他订阅者 |
| viewer.pick({x,y},{tolerance}) | canvas左上角为原点的CSS像素；返回最上层命中对象快照或null，默认容差6px |
| viewer.pickPosition({x,y},options?) | 默认求当前显示地表网格交点；支持明确指定参考椭球或固定绝对高度面，详见§4.3 |

示例点击查询：从event.clientX/clientY减去canvas.getBoundingClientRect()的left/top再传给pick，不乘devicePixelRatio。单击新增点采用拾取位置及高度，不再取椭球经纬度后硬加1500米；多点绘制使用viewer.draw，详见§4.3。

符号与高度边界：

- 坐标WGS84度、第三维为椭球绝对高度米，省略时30米。默认30米是无地形时的显示抬高，不是采样地形。显式0仍为0；开启地形不会自动抬高或持续贴地。默认正常深度，低于山体会被遮挡；可选择occlusion:overlay置顶表达，明确不作为贴地。
- 点circle/square/diamond或URL图标，size/outlineWidth为CSS像素；宽线为GPU屏幕挤出，不依赖原生WebGL线宽。线端为butt，连接仍为简化效果，不是完整制图级join/cap；纹理与虚线按可见路径屏幕长度累计。图标/流动纹理见§4.2；不支持自定义字体资源或建筑拉伸。
- polygon是真实填充，支持凹外环、洞和轮廓；fill:false仅轮廓。闭合末点可省略；自交、相交/触碰环、洞在外部、嵌套洞、零面积拒绝。局部面经纬各跨度最多1度，支持局部跨日界线；区域/全国面优先使用已有瓦片图层。显式0高度和很长线段/复杂面仍可能受曲率及细分预算影响，不承诺任意全球曲面贴合精度。
- 颜色CSS命名色或3/6位hex，透明度用opacity；尺寸/坐标输入、符号字段、几何规模均校验。EntityError.code为INVALID_ENTITY/DUPLICATE_ID/NOT_FOUND/DESTROYED，不能混同ViewerError。
- 标注是GPU屏幕朝向文字，可配颜色、光晕、背景、字号、offset；offset正x向右、正y向下。几何附属标注锚在首顶点；需要另一个锚点时使用独立label对象。文字最多512字符，显示最多8行、宽度1024CSS px（超出裁切）；使用系统sans-serif，不是完整glyph/sprite/symbol-style兼容系统。
- 标注有画布/椭球遮挡裁剪、32px网格碰撞及最多256个可见限制，高order优先占位；正常模式地形遮挡交给GPU，overlay模式关闭符号深度测试但不改高度。业务order范围0..9000，底图引擎注记保持既有上层顺序。点／文字pick可用当前地表深度排除正常模式的遮挡对象；线面仍是屏幕几何近似，不是任意模型/透明材质深度拾取。
- 默认最多5000对象、单几何10000输入点，线细分有界，面有曲率细分和规模限制；这是可编辑业务对象系统，不承诺数万密集对象60FPS。只重建脏对象，每帧最多8个/2ms软预算；一个任务不能被预算中途抢占。样式/几何跨帧生效，更新期间保留旧显示；remove/隐藏立即影响显示与拾取。
- destroy释放集合、材质、纹理、几何和订阅；之后集合读写拒绝。不要手动移除__sdk_entities或调用其dispose后继续使用Viewer的entities。EntityCollection单独导出便于无WebGL管理/测试；EntityLayer是低层适配器。

## 4.2 图标朝向、线方向纹理和面滚动材质

用户提供两张示例PNG已放入独立应用public：`mylocation_up.png`本来向上（sourceHeading:0），`Qianjin_left.png`本来向左（270度、sourceDirection:left）。引擎dist/tgz不携带这些图片；任何消费者自行部署自己的图片URL。图片不是底图或业务瓦片，不能按XYZ/TMS再翻转。

```js
viewer.entities.add({ id: 'person', type: 'point', position: [106.55,29.61,1500],
  symbol: { icon: { url: './mylocation_up.png', width: 36, height: 36, sourceHeading: 0 },
    heading: 0, alignment: 'map', color: '#ffffff', opacity: 1 } });
viewer.entities.update('person', { symbol: { heading: 90 } }); // 朝东，不再下载图片/重建几何

viewer.entities.add({ id: 'flow-route', type: 'polyline',
  positions: [[106.52,29.60,1500], [106.55,29.61,1500], [106.59,29.62,1500]],
  symbol: { width: 24, color: '#ffffff', opacity: 0.9,
    texture: { url: './Qianjin_left.png', sourceDirection: 'left', length: 48, speed: 30 } } });

viewer.entities.add({ id: 'moving-area', type: 'polygon',
  positions: [[106.51,29.63,1500], [106.57,29.63,1500], [106.57,29.67,1500], [106.51,29.67,1500]],
  symbol: { fill: true, color: '#ffffff', opacity: 0.5, outlineColor: '#ffffff', outlineWidth: 2,
    texture: { url: './Qianjin_left.png', repeat: [8,4], offset: [0,0], rotation: 0, speed: [-0.15,0] } } });

viewer.entities.update('flow-route', { symbol: { texture: {
  url: './Qianjin_left.png', sourceDirection: 'left', length: 48, speed: 0 } } }); // 停止流动
viewer.entities.update('person', { symbol: { icon: null } }); // 退回简单点符号
viewer.entities.update('moving-area', { symbol: { texture: null } }); // 退回纯色填充
const resource = viewer.getEntityResourceState('person'); // none/pending/loading/ready/error；不存在返回null
viewer.retryEntityResources('person'); // 显式重试失败图片或纹理预算受限标注，返回是否排入重试
```

朝向与动画契约：

- heading顺时针度数。alignment:map（默认）以当前位置投影的地理北为0，地图旋转时图标随地理北变化；screen以屏幕上方为0。sourceHeading表示原素材方向，最终旋转为目标朝向减原朝向，再加地图北向；原向左图标若要朝北，sourceHeading设270而非修改PNG。宽高为CSS像素，省略用size，图标默认32px。
- 线width必须大于0才制作条带；图片沿positions方向排列。sourceDirection:left把向左素材校正为沿坐标顺序向前，right为原素材向右。length是沿路径的重复周期CSS像素，speed为CSS像素/秒，正数沿坐标顺序、负数反向、0静止。虚线和箭头使用累计屏幕长度，相机姿态变化时更新长度属性，静止不重算；连接处仍不是完整制图级圆角/斜接。
- 面纹理UV由局部经纬包围盒归一化；repeat为重复次数，offset为初始UV偏移，rotation为顺时针纹理旋转度数，speed为纹理坐标轴上的平移UV/秒。rotation:0时U向东、V向北，向左箭头配负U流速显示向西移动。旋转后运动轴一起旋转；不是世界米/秒，也不是按地形坡面面积等距铺图。
- color乘到纹理上，保留原图片颜色用白色；opacity与图片alpha共同生效，面孔洞仍为空。图标和纹理可动态修改/移除；symbol浅层合并，但icon/texture描述整体替换，修改纹理speed时请保留url等字段。
- PNG/JPEG/WebP，远程图片需要CORS；支持相对/HTTP(S)/blob及对应base64 data URL。不支持任意脚本URL。加载最多4并发、256个ready/loading共享图片，单图片≤8MiB且≤2048×2048；15秒超时，不影响地图瓦片队列。图片与文字纹理共同受64MiB估算RGBA上传预算约束（不含解码临时内存）；预算不足时可暂停新符号纹理/文字并报告error，不无限扩张显存。超限制/404/CORS失败暂显示简单几何，不冒充纹理已经就绪；公共状态不回显带凭据URL。修复服务或释放其他对象后调用retryEntityResources显式重试，不自动无限重试坏URL。
- 按URL共享引用，样式更新先取得新引用再释放旧显示；最后一个使用者删除后取消请求、关闭ImageBitmap并释放GPU纹理。迟到图片不会覆盖已删除或新建对象。GPU上传前ImageBitmap显式翻转一次，方向回归覆盖上/下和顺时针旋转；这不改变底图XYZ/TMS约束。
- 流动动画每帧仅修改相位/UV偏移uniform，不重建网格、标注或重复下载。stop暂停渲染，动画时间当前为实例墙钟，恢复时相位会追上当前时间；尚未提供暂停时间轴或动画完成事件。

## 4.3 当前项目调试、显示地表拾取与基础鼠标绘制（2026-10-10）

引擎根目录index.html也有测试入口，不只独立SDK demo。CMD：

```bat
cd /d E:\SpringAndAutumnGIS\SpringAndAutumnGIS
npm run dev
```

打开终端实际地址的/index.html。此源码页依赖Vite转换TS，不能通过file://或Live Server直接运行；引擎dist仍只输出库，不改成网站。独立应用继续安装dist/tgz并用自身dev/preview。

当前左下工具栏“绘制”图标打开包含完整对象管理的面板；里面有明确的“绘制点／绘制折线／绘制面／绘制标注”按钮，不是只勾选单击加点。“测量／查询”图标可选点属性查询，不强制定位；完整表单仍提供拾取诊断。永远村和行政区GeoJSON快捷定位收进“业务图层”面板，数据源不删除；独立demo重复的旧合成GeoJSON点线面示例已移除。

```js
viewer.draw.start({ type: 'polyline', id: 'route-from-mouse',
  symbol: { color: '#00ffff', width: 4, occlusion: 'overlay' }, pick: { mode: 'surface' } });
// 逐点点击地图，鼠标移动时有线段预览；至少两点后：
const line = viewer.draw.finish(); // 加入同一个viewer.entities，返回只读快照
viewer.draw.start({ type: 'polygon', symbol: { color: '#32e6a1', opacity: 0.35, occlusion: 'overlay' } });
viewer.draw.undo(); // 撤销当前最后一个顶点
viewer.draw.cancel(); // 丢弃预览，不删除已提交对象
viewer.draw.start({ type: 'point', symbol: { icon: { url: './mylocation_up.png' }, occlusion: 'overlay' } });
// 点和标注每次单击提交一个对象，默认持续操作；draw.stop()结束；continuous:false则单击后退出。
const unsubscribe = viewer.draw.onChange(state => console.log(state.active, state.type, state.vertexCount, state.lastEntityId));
```

绘制开始时取消未完成飞行，默认只独占左键，右/中键与滚轮继续导航；可显式navigation:lock，完成/取消/销毁后恢复此前导航状态。Enter完成，Esc取消，Backspace/Ctrl+Z撤销顶点（输入框内不抢占编辑）。切换模式取消旧预览；非法自交面或顶点不足不会提交，保留当前会话供撤销/修正。当前鼠标上限1000顶点；面只绘外环，孔洞可通过实体update后加。符号和拾取配置在start时捕获，结束后可继续编辑。高级捕捉、顶点拖拽、Redo、触屏绘制仍未实施；持续贴地见§4.4，测量见§6.1。

鼠标绘制线/面在两个demo里默认持续贴地并使用正常深度；临时预览置顶，最终提交跟随显示地表。API创建实体与未指定occlusion的draw仍默认正常深度。overlay是关闭指定对象材质的depthTest、保留depthWrite:false和既有绘制顺序；不修改经纬度/高程，不是伪造贴地。点与文字保留地球背面剔除和标注碰撞限制；线面采用保守包围体剔除，跨地平线的大图形并非逐像素精确遮挡。

```js
viewer.entities.update('station', {
  symbol: { occlusion: 'overlay' }, label: { occlusion: 'overlay' }
});
// 改回正常深度：occlusion:'depth'。独立文字在label上设置。
// 附属点标注未显式指定时继承点策略；显式label.occlusion可单独控制。
const rect = viewer.engine.renderer.domElement.getBoundingClientRect();
const screen = { x: event.clientX - rect.left, y: event.clientY - rect.top };
const actual = viewer.pickPositionDetailed(screen); // 默认mode:'surface'
const reference = viewer.pickPositionDetailed(screen, { mode: 'ellipsoid' });
const fixed = viewer.pickPositionDetailed(screen, { mode: 'absolute-height', height: 1500 });
```

默认拾取使用当前base影像／原生矢量的实际显示地表三角网格，复现现有shader的DEM采样（线性/最近邻）、XYZ UV绑定、局部高精度路径、曲率和公共边ECEF覆盖。不是拿“最新下载DEM”改高度，也不是把椭球交点垂直抬升。无可用base网格时明确返回source:ellipsoid，天空/画布外返回null。不会为拾取额外请求DEM，不改变瓦片/地形LOD；CPU顶点缓存按几何/纹理版本失效，在查询时懒制作，不每帧扫描网格。高频拾取/BVH和独立有效地表接口仍需后续性能工作。

pickPositionDetailed提供position、source、tile、screen、reprojected、errorPixels、distance和viewDepth。诊断同时显示椭球对照；斜视时高度差会造成经纬度差，不能因“不看高度”就排除其影响。它是显示地图地表查询，不是建筑/模型/透明纹理任意深度缓冲拾取，也不是高度量测真值。拾取顶点保存点击时的高度；absolute对象不自动变化，clamp-to-ground对象的显示随地表细化，但不改保存坐标。

验证：npm run test:picking与npm run test:entities:browser。后者显式entitySmoke=1使用本地合成栅格/DEM，在root index验证单canvas、DPR=2、页面偏移、地形开/关、GPU点击点像素、折线/面绘制、撤销/取消/导航恢复、置顶与背面剔除；阻断外部请求，不用真实服务压测。受控点击回投约0.000001px，不证明所有实景服务配准或FPS已验收。普通URL不启用合成回退。

## 4.4 持续贴地、置顶图标与抗闪烁（2026-10-10后续）

此前线面只有绝对高度快照/置顶表达。现在增加heightReference:'clamp-to-ground'，复用当前base显示三角网格：线按地表三角形边界裁剪分段，面/洞与地表三角形求交并做同平面重心插值。不是只采输入点后连大三角形，也不是转图片兜底；当前地表LOD/DEM版本变更会重新构建。无地形时跟随当前显示椭球网格，有地形时跟随已显示DEM及共享边；不额外请求DEM，不改地形LOD。

```js
viewer.entities.update('route', {
  heightReference: 'clamp-to-ground', groundOffset: 0.5,
  symbol: { occlusion: 'depth' }
});
viewer.entities.update('area', {
  heightReference: 'clamp-to-ground', groundOffset: 0.5,
  symbol: { occlusion: 'depth' }
});
viewer.draw.start({ type: 'polygon', heightReference: 'clamp-to-ground', groundOffset: 0.5,
  symbol: { color: '#32e6a1', opacity: 0.4, occlusion: 'depth' } });
const state = viewer.getEntityGroundState('area');
// absolute / pending / ready / unavailable / limited；含revision、patches、vertices、message
```

贴地忽略坐标第三维的渲染高度，但不重写实体保存的positions；如需再用第三维，改回heightReference:absolute。groundOffset是沿显示地表三角形法向的渲染抬高量，范围0–10米、默认0.15米，专用于避开接面闪烁；可以设0.5/1米对照，不把它当作业务海拔。另对贴地材质使用约0.5米的有限对数深度偏置，仍保留depthTest，不是将全部图形永远覆盖地形，也不改变已有系统注记排序。

宽线顶点的屏幕挤出会重新求交所在地表平面，而不保持错误的中心深度；连续路径长度用于纹理/虚线流动。非常宽的线在陡峭三角形接缝仍有局部平面近似，尚不是逐片元地形分类通道。面UV用局部Mercator归一化，凹环/洞与动态纹理保留。

构建跨帧续作，约2ms软预算/8实体；128个地表三角形一个续作检查点。上限400000次相交检查、150000输出顶点，超限明确limited，不默默降成平面。只覆盖已显示base patch；离屏/缺失区域等待，unavailable不伪造零地形。无base网格时不提供持续贴地替代面；绝对高度模式仍可显示。地表更新时旧对象有界等待新构建完成；状态pending不表示新地表已对齐，长时间等待请看诊断。不承诺无限规模/全球多边形贴地或建筑表面吸附，极区超出Web Mercator覆盖拒绝。

点图标之前看似置顶失效的路径：绘制点未自动选择overlay，以及CPU的分析椭球地平线判断仍隐藏近侧低视角点。现两种demo的点/标注绘制与人物示例明确overlay；overlay只做远侧半球剔除，近侧符号不再被分析椭球深度拦住。正常depth仍按原遮挡。点也可选择clamp-to-ground，标注未指定时继承点策略；显式label.occlusion可独立设置。可见性仍受视口/碰撞/数量限制，不是让地球背面全部透出来。

绘制预览与最终贴地拆开：移动鼠标的橡皮筋预览是临时absolute+overlay，不在每次移动取消/重启贴地裁剪；完成后再交付所选的实时贴地实体。这种临时预览不是最终贴地精度。拾取用高程范围及实际共享边缓存紧包围球，替代所有近景patch一律+30km的大球，以免每次指针移动都扫描大量瓦片。

draw.state提供pickMs、previewMs（CPU）和previewFrameMs（预览更新回调时间，非屏幕呈现硬件时间）。面板直接显示，便于拆分400ms是拾取、重建还是渲染等待；40ms鼠标预览节流仍保留。测试用软件GPU/合成地形测量，不承诺所有实景400ms均同因或固定FPS；持续低延迟/大对象构建仍须按实际设备和轨迹评估。

性能收尾记录：软件GPU中曾观察到拾取CPU约1–2ms但首预览约966ms；材质复用、单通道透明绘制与模式开启时有限预热后，软件末轮CPU约1–2.5ms、更新约270–300ms，严格250ms目标仍未稳定通过。硬件模式同场景末轮CPU约2.8–3.6ms、更新约12–20ms，并通过PNG置顶/正常遮挡、贴地面实际像素验证；不据此承诺所有实景设备同样延迟。

复用实现曾错误替换uniforms对象，但WebGLRenderer保留旧对象引用，导致面缺失；已改成原位清空/更新，避免旧原点或纹理被上传。材质池最多8个、销毁释放，不无限保留程序。软件回归采用400ms报告边界并输出数字，硬件/软件分开记录；冷编译和用户原轨迹仍须跟踪，抗闪烁机制不代表所有驱动/极近视角都已无问题。点/文字也使用有限0.5m眼向深度偏置，数据坐标不变。

## 5. 用户资源与凭据

独立应用要求用户填写自己的token.json，缺少底图/DEM不启动普通地图；HTTP页面仍可显示配置提示。这是交互应用的约束，Viewer库本身仍允许不配置地形。

独立应用不再import token.json，不把Key嵌入JS。开发/preview通过应用自身的同源/token.json接口返回允许公开的配置，服务端字段剔除；build不自动发布配置。静态部署时显式运行应用npm run config:deploy，或部署自己管理的授权网关/配置。

发布只提供token.example.json、公开服务说明与资源申请教程。不分享维护者Key，不把OSM或云平台资源当成无限免费兜底。浏览器配置是公开数据，不是加密文件，只能放限制域名/权限/配额的客户端Key；服务端Secret必须留在后端。当前本机天地图曾返回429，不宣称真实服务权限/配额已验收成功。

## 6. 验证职责

## 6.1 图标工具栏、相机恢复、测量与属性查询（2026-10-11）

```ts
import { Viewer, measureDistance, measureArea } from 'spring-and-autumn-gis';
const viewer = await Viewer.create('map', {
  basemaps: myBaseMaps, terrain: myTerrain, toolbar: true
});
// 或初始化后显式创建；默认不创建DOM工具栏。
const toolbar = viewer.createToolbar({ baseMapNames: { satellite: '卫星影像' } });
viewer.orientNorthUp(); // 姿态变为北向俯视，不移动相机或改变高度、FOV、near/far
viewer.resetView();     // 恢复创建时的相机位置、姿态；不同于指南针
viewer.setTileLevelOffset(-1.0); // 当前底图和其配套注记，不改变业务图层偏移
const distance = measureDistance([[106.55,29.61],[106.56,29.62]]);
const area = measureArea([[106.55,29.61],[106.56,29.61],[106.56,29.62]]);
viewer.measure.start('distance'); // 或 area；共享 viewer.draw 输入系统
// 线至少2点、面至少3点；Enter/工具面板完成，Backspace撤销，Esc取消。
viewer.measure.onChange(state => console.log(state.result));
// finish()结束当前测量，clear()只移除该测量控制器创建的结果实体。
const hit = viewer.inspectAt({x:200,y:150}); // canvas相对CSS像素
// hit.surface: 经纬度、高度、来源、回投误差；hit.entity: 自有实体属性/符号/几何快照
```

工具栏默认在地图容器左下角纵向排列（36×34px按钮，25px图标），距底部48px+safe-area；复杂设置与结果在右侧弹窗，底图和偏移是工具栏旁的紧凑弹窗。测量仅measure-distance图标、绘制仅polygon图标，弹窗选择点线面，默认点；包含初始视角、指南针和地形，对象管理在绘制内部，可选业务图层管理。悬停提示和aria-label保留功能名称；小高度容器可滚动。需要容器有明确高度。toolbar.destroy()仅卸载工具UI，viewer.destroy()同步清理工具、测量和绘制监听器。重复createToolbar会替换旧UI，不创建第二个地球/canvas。推荐drawContent内嵌应用管理表单；onEntities可在绘制面板内部触发已有应用管理，onLayers扩展业务层入口。

绘制默认navigation:'allow'：左键由绘制以捕获阶段独占（不拖地图），右键旋转、中键俯仰、滚轮缩放仍可用；拖动右键不落点，移动后的点击重新拾取当下显示地表。需要原行为可用viewer.draw.start({type:'polyline',navigation:'lock'})。若应用原本禁用相机，不擅自启用；结束恢复之前enabled状态。贴地细化期间最终实体跟随当前显示地表，不改变保存的顶点。

测量口径为WGS84椭球测地线：distance.metres/segments（米）；area.squareMetres（平方米）、perimeterMetres（米，含孔洞周长）。point返回坐标、拾取来源及可选approximation。使用GeographicLib，支持日期变更线、反向环和孔洞面积扣减；纯函数输入需有效、非自交外环及内部不相交孔洞，较小区域面积，不用于大于半个地球的区域解释。高度不影响距离/面积数值，不称为沿山坡距离/山坡表面积。交互绘制继承当前局部面最大跨度与拓扑校验；未实现全世界任意巨大交互面。属性查询仅覆盖本引擎entities及显示地表，不宣称能返回所有MVT/GeoJSON/WMS源要素属性。测量结果存入实体properties.measurementResult，是完成时的快照；后续编辑几何应重新调用measureDistance/measureArea，不自动改写快照。

src/assets/img/NEW中的图片全部改为英文文件名，地形/测量/要素目录分别为terrain/measurement/entities；home、basemap、compass、tile-offset、entity-manager、layers等用于工具栏。Vite库构建将工具图标内联，消费者不需要引擎src目录；许可证生成到dist/THIRD_PARTY_NOTICES.txt。只有UI图标随包提供，不含维护者token或底图/DEM资源。

源项目index.html使用同一个公共ViewerToolbar，通过轻量适配器复用已有引擎和右侧测试面板。顶部旧文字按钮隐藏，仅保留ID作为事件适配；“图层”按钮打开业务图层，“绘制”内嵌点线面完整表单。独立项目TS/JS demo均创建已安装dist的工具栏，无源代码联接。

本轮验证：typecheck、完整npm test、test:measurement、test:ground、test:picking、test:sdk；根页面硬件GPU无地形/合成地形浏览器回归，新增实际右键导航、姿态/位置不变、图标解码、面板挂载、点查询、路程/面积完成、清理所有权。测试不请求真实地图，不视为实景服务或性能验收；地形LOD、队列和业务图层排序未改变。

- 引擎：npm test、npm run typecheck、npm run test:sdk、npm run test:entities；保持原有渲染回归。
- 独立应用：npm run build、npm run test:sdk、npm run test:sdk:browser，检查已安装dist、TS/JS交互、真实GPU填充/洞/文字/图标方向/线面滚动/透明度、资源隔离与销毁重建。
- SDK源码更新后显式build和sdk:update；日常应用启动只npm run dev或preview。
- 历史examples/sdk-consumer已ZIP归档，见archives/README.md；日常交互以独立应用为准。

## 6.2 连续点、双击与极圈补面（2026-10-11后续）

测量默认选择点坐标／高程，另可选距离、面积或对象属性查询；绘制默认选择标记点，另可选折线、面、标注。打开或切换类型只进入待开始状态，必须点击独立“开始测量／开始绘制”才接管输入；完成后可再次开始，不必切换类型。测量和绘制各一个图标；对象管理已收进绘制，当前标准SDK 7个、源码demo附带业务图层共8个。底图/偏移弹窗定位于工具栏旁，不占右侧大面板。

```ts
viewer.draw.start({type:'point'}); // 每次点击提交一个新marker，仍保持active
viewer.draw.stop();              // 代码结束，保留已提交点；没有点也可以结束
viewer.draw.start({type:'point',continuous:false}); // 兼容一次点击退出
viewer.measure.start();         // 等同 start('point')，连续拾取
viewer.measure.stop();          // 结束但保留已提交测量点
toolbar.endInteraction();       // 结束当前工具输入，弹窗保持打开
toolbar.close();                // 关闭且退出；切换模式也退出旧会话
```

折线/面双击或Enter完成：第二次释放不重复加入末端点；尊重浏览器/OS较长双击间隔。顶点不足/拓扑错误不会误提交，继续会话供修正。点/标注双击不结束，Enter、结束按钮、stop、close或销毁结束。点undo删除本会话最后一个已提交点；cancel/关闭不删除已经落下的点。单会话仍有1000顶点上限。state.lastPick提供最近拾取诊断；result实体仍可通过entities管理。右/中键、滚轮继续导航。

极圈现状：默认瓦片域约±85.0511288°，不是完整极地覆盖。PolarSurfaceLayer填补域外南北两圈；读取当前base显示边缘的影像纹理、祖先UV裁剪与CPU地形三角形，外沿沿用同一高度。最新整圈颜色采用每个地图自己的预制贴图（§6.4），高程仍向参考椭球衰减。不会翻转XYZ/TMS，不额外下载DEM，不把经线图像无限拉到极点；切换底图同步换边缘采样，透明无数据像素不涂黑。基底不叠在已采样地形扇区下，避免零高度底面遮住负高程扇区。

补圈是显示近似，非真实极地影像/DEM。TerrainTileLayer.sampleHeight在域外返回null、heightVersionAt为polar-no-dem；pickPositionDetailed的补圈命中标记approximation:polar-cap，不能当作真实高程。相机离地间距通过补圈自身的少量三角形查询计算，不从边缘DEM夹取高度，不混进真实DEM API。附近/远处两档补圈网格带滞回和可见半球筛选；这不是独立地形LOD的实现，不改变普通瓦片选择/请求队列。polarSurface:false可禁用；非Mercator格网默认不启用该补面。

真正极地地形仍需极地覆盖的地理/极地投影影像和DEM服务、明确CRS/覆盖/行号约定，并增加重投影及接边适配；目前服务和MVT/栅格管线不能被声明为已支持任意极地投影。持续贴地的线面仍限Mercator域；极地点标记/拾取可用absolute坐标与显示补圈查询。测试覆盖南北±88°、正/负边界高程、祖先UV、资源借用/换底图、近景间距和双击/连续输入；不证明真实极地精度及全轨迹性能。

## 6.3 显式开始、历史清理与南北极默认差异（2026-10-11）

弹窗新增“开始测量／开始绘制”和各自的“新对象提交后清除历史对象”复选框，默认不勾选（保留）。打开、类型切换、勾选、点击开始均不立即删除旧对象；只有新对象成功提交才替换本工具历史。点模式勾选时每次落点只保留最新点；线面勾选时完成新几何后替换旧结果，预览、取消、无交点、顶点不足/非法几何都保留旧结果。设置在点击开始时捕获，活动会话中修改勾选项应再次开始以应用。

清理采用控制器所有权，不通过id前缀或properties猜测。绘制与测量分别管理，普通entities.add的业务对象不会被清理；删除后同ID重新加入的普通对象也不继承旧所有权。clearPrevious只负责替换本工具已生成的结果；draw.clearHistory()显式清绘制历史，measure.clear()显式清测量历史。被清理对象不提供自动恢复，需提前保存实体JSON自行恢复。自定义onDraw回调第二参数为{clearPrevious}，应用需要将该参数传给draw.start。

```ts
// 无真实极地影像时，默认北极采用海洋色，南极采用冰雪色，可按底图风格覆盖：
const viewer = await Viewer.create('map', {
  ...yourOptions,
  polarSurface: {northColor:'#244d66',southColor:'#edf2f6'}
});
viewer.draw.start({type:'point',clearPrevious:true});
viewer.measure.start('distance',{clearPrevious:true});
viewer.draw.clearHistory(); // 只清绘制控制器拥有的对象
```

此前南北两圈虽然取各自边缘行，但默认无数据色都接近雪白，视觉差异不明显。北极海洋蓝、南极冰雪白现在只作最终缺数据兜底，正常整圈由当前地图预制贴图决定（§6.4）；不共用南极纹理、不新增行号翻转。此设置不代表真实海冰范围、海岸线或地形影像。补圈approximation标记和真实DEM缺失行为不变，不能以颜色差异宣称真实极地数据已接入。

## 6.4 所有底图统一自适应极圈预制（2026-10-11）

Google、天地图、Esri、OSM、MapTiler以及自定义XYZ/WMTS/TMS和原生/兼容矢量底图，全部走同一PolarAppearance准备流程，不按厂商写死颜色表。当前地图加载后自动准备自己的南北贴图，换底图换贴图，缓存命中直接复用；不是只在边缘借一条纹理、圈内统一蓝白。

- 栅格：先采样该地图已加载的南北边界瓦片（含缓存的非可见祖先），按全球经度组织两条环状像素谱。颜色沿纬向逐步平滑，整圈预制成两张256×32 RGBA atlas；极点收敛到本地图对应半球的采样均值，消除经线条带和极点奇点。透明像素视为无数据，不填黑。高细节样本可更新自己的分区，南北分别采样，不互换行号。
- 矢量：在像素尚未就绪时，按已解析Style v8的背景、海洋、水、冰雪和陆地填充生成本样式的初始atlas；支持原生GpuVectorTileProvider和MvtRaster/ArcGIS兼容Provider。原生GPU制图纹理由小型离屏采样读取，不回到Canvas矢量渲染兜底；实际像素就绪后更新atlas。无法识别的样式语义回退到可用背景，仍受现有样式表达能力限制。
- 稳定身份：URL模板/覆盖配置、矢量样式/source使用配置指纹，不以camera LOD revision作缓存身份，不同服务、同ID不同URL或明暗样式隔离；URL/token不作为状态返回字段。普通缩放不销毁预制结果。缓存默认24张地图，每图两张atlas共64KiB原始纹理，默认约1.5MiB；派生像素不依赖原Provider纹理继续存活。
- 自动补样本：地图激活1.5秒后，仅当前景loading<2且queued<8时，最多1个额外低层级请求并行，优先复用已加载瓦片；通常z1的4张瓦片即可采到南北完整边缘。minLevel超过3的局部/高层级源不全世界穷举。请求默认5秒超时，切换/销毁取消，迟到纹理释放；失败计数不使普通底图崩溃。不额外请求DEM，不批量初始化所有未选用地图，不把维护者资源放入SDK发行包。

```ts
const viewer = await Viewer.create('map', {
  ...yourOptions,
  polarSurface: { warmup:true, maxCachedMaps:24, requestTimeoutMs:5000 }
});
console.log(viewer.getPolarSurfaceState());
// mapId / north、south的mode与coverage / warming / queued / failures / textureBytes
// mode: sampled=本图像素生成；style=本图样式生成；fallback=没有可用数据。
```

coverage表示边缘环的经度样本覆盖比例，不是极地影像或DEM覆盖/精度。部分样本时缺口可按该图已有像素均值估计，不能解释为真实极地像素；fixed northColor/southColor仅在没有样式/像素时兜底。warmup:false可禁止额外影像请求，仍使用现有像素与样式自适应。服务不可用、凭据不足、CORS/读回失败可能保持style/fallback，必须看状态，不能承诺所有服务无条件准备完成。源码统计面板显示极圈来源、样本比例和预制排队/失败数。

这是按底图自适应预制的显示补圈，不是发布包内预置所有厂商真实极地图像；每个消费者使用自己的资源配置生成。真实极地海冰/地貌/影像和DEM仍需要相应数据及投影适配，approximation:polar-cap和DEM域外null保持不变。测试以受控数据检查不同地图/样式的整圈像素、缓存隔离、透明无数据、纹理方向和GPU读回；不宣称真实Google/天地图/Esri服务已逐一通过权限/配额验收。

## 6.5 地形独立LOD初版与近景推进（2026-10-11）

GlobeEngine/Viewer在Web Mercator网格下默认启用独立DEM选择，`terrainLod:false`恢复共享选择用于对照；不支持的其他网格目前保留共享路径。单独使用TerrainTileLayer仍默认接收调用方叶子，不自动建立相机选择器。requestPriority默认camera-near，负责请求/解码/上传顺序，与选择层级分开。

```ts
const viewer=await Viewer.create('map', {
  ...yourOptions,
  terrainLod:{maximumScreenSpaceError:3,maxTiles:96,maxSurfaceTiles:512,
    samplesPerTile:256,estimatedSlope:0.25,updateIntervalMs:100},
  terrainLayer:{requestPriority:'camera-near',preemptFarDetail:false}
});
console.log(viewer.engine.terrain?.stats.requestPriority);
console.log(viewer.engine.terrain?.stats.preemptedRequests);
// terrainLod:false 对照旧共享选择；preemptFarDetail默认关闭。
```

排序用相机到可见瓦片地理范围最近点的估算距离（包括已加载高程），不是只看视口中心或瓦片中心。距离分带后结合screenPixels/中心偏好，减少小幅抖动；相机移动超过小阈值后更新，即使LOD选择数组仍是同一个引用也重新排序。数据上传和区域发布消费同一近景排序；共享DEM Worker在下一项解码开始时读取实时优先级，不重启正在运行的不可分割任务。未指定Worker优先级的矢量等其他客户端保持FIFO。

独立选择用几何误差米数投影到屏幕，不把影像的掠射角清晰度梯度直接作用于垂直高程误差。TerrainProvider可提供geometricError(tile)返回数据集误差米数；没有时采用显式分辨率/坡度估算和椭球网格弦高，不是经测绘认证的误差上界。DEM样本密度/坡度要匹配自己的服务；maxTiles是DEM目标预算，不是影像数量。实际准入还按已观察的单DEM CPU/GPU字节数收紧，预留父覆盖与在途空间，不靠把缓存塞满追求精度。接近俯视不施加固定层级降级；接近水平按距离/误差自然形成梯度。provider.maxLevel仍是数据源真实上限，不能用过缩放凭空增加高程细节。

独立路径先取得真实数据集根覆盖，有有效祖先后近景直达自己的目标DEM，覆盖/细节3:1公平启动。根404时转入局部粗片再细化；错误/缺数据不伪造0高度，未覆盖patch隐藏。首次覆盖与目标达标分开统计。共享旧路径仍沿用原整体冷启动覆盖门槛。重选后仍与新视口相交的loading/pending允许完成，不因为目标换一级就反复取消；完全离开的未就绪资源仍清理。

栅格及GPU制图底图拆开请求覆盖与绘制覆盖：先按原影像叶子请求，再以已就绪DEM细分公共地表网格，子网格采样原影像祖先UV，不增加影像请求zoom。复用共享ECEF边界、GPU高程绑定与实际地表拾取，避免父子重复绘制。maxSurfaceTiles限制网格放大；统计terrainSurfaceLimited报告已就绪DEM因公共地表预算尚不能完整表达的数量。surfaceTiles不是DEM请求数，也不是原影像selected数。原生业务MVT的粗源几何仍使用现有单DEM绑定，跨多个更细DEM的业务几何分块/atlas还需下一阶段，不能宣称本轮已经彻底完成所有矢量贴地精度解耦。

实验regionalCoverage路径仍须显式启用，默认不改：根/父依赖继承最近可见后代优先级；根就绪后父片推进，父片就绪后请求子片。齐备的近景局部事务先发布，事务内父字段先于子字段准备、已有一致提交跨帧续作不因每次移动重启。既有邻接边带/CPU-GPU同代发布约束保持，不将纯排序修复等同接边算法全面修复。

远景让位现默认关闭：上一轮每次pumpQueue都可触发取消，慢网络时存在静止反复重启的风险。显式preemptFarDetail:true时，仅有实际位置移动才能重新允许一次让位，同时保留750ms冷却、可信父覆盖和距离门槛；静止时响应/上传完成不重新授权取消。不能强制中断Worker内的原子解码。迟到数据释放，真实请求超时仍有限重试；TileJSON动态揭示较低maxzoom时，祖先响应按真实id入库，不能冒充子瓦片坐标。

源码页直接使用新默认；`?terrainLod=shared`对照旧选择，`?terrainPriority=screen-error`仅对照排队顺序。面板增加LOD模式、DEM目标/达标数与目标层级、DEM源级别、公共地表网格/限精度数。API同字段位于onStats的terrain、surfaceTiles和terrainSurfaceLimited。terrain.sourceMinimumLevel/sourceMaximumLevel是当前目标可解析的DEM源范围，不能误读成影像zoom或全部mesh均已达标。不要用60FPS或coverageReady代替readyTargets达标。

验收：npm run build后运行npm run test:terrain:independent及npm run test:terrain:priority。受控257×257慢DEM、每请求模拟1.6s，19目标+1根在9.64s模拟时钟完成，无取消、无重复、队列归零；这不是实际网络加载时间保证。4km合成地表、相机离地1km，俯视/45°/80°/87°的DEM目标为11/16/26/25，近范围z14/z14/z14/z13；不等于真实珠峰数据验证。root失败、源上限动态变化、影像请求/网格层级分离和预算均有回归。实际用户山地轨迹、刀片的动态视觉验收、可靠父子一致发布与实测残差误差元数据仍保持开放，不能宣称“一劳永逸”。

源码demo默认开启，可用URL的terrainPriority=screen-error对照；terrainCoverage=regional仍单独控制实验接边策略。状态面板显示调度模式和“远景让位”计数。受控测试覆盖近景高层级/远景低层级、父覆盖、粗片缺失、同引用相机移动、上传顺序、区域齐备提交、日期变更线、大瓦片最近范围、Worker动态排序/公平和迟到清理。网络/解码延迟、缓存容量不足或接边依赖未齐仍可导致等待，本轮不承诺实景3–20秒地形更新或刀片问题全部消失。
